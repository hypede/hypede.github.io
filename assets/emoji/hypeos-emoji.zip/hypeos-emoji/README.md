# Эмодзи HypeOS / HypeOS emoji

46 эмодзи в стиле HypeOS: лица, символы и значки вроде `sudo` и `btw`.
Ими можно пользоваться где угодно — в Telegram, Discord, на сайтах и в своих
программах — на условиях **GPL-3.0-or-later** (текст — в `LICENSE`).

46 emoji in the HypeOS style: faces, symbols and badges such as `sudo` and
`btw`. Use them anywhere — Telegram, Discord, websites, your own apps —
under **GPL-3.0-or-later** (see `LICENSE`).

- `svg/` — исходники 128 × 128 / sources, 128 × 128.
- PNG 128 (Discord) и 512 (стикеры Telegram) / PNG for Discord and Telegram
  stickers:

  ```bash
  python3 tools/gen-emoji.py --png /tmp/hypeos-emoji
  ```

Набор рисует `tools/gen-emoji.py`: чтобы поправить эмодзи, меняйте скрипт, а
не SVG. / The set is drawn by `tools/gen-emoji.py`: edit the script, not the SVGs.

Скачать архив / Download: https://hypede.xyz/emoji/
